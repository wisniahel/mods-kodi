#      Copyright (C) 2019 Mariusz Brychcy
#
#      Some implementations are modified and taken from "plugin.video.hejotv" - thank you very much mbebe!

import os, copy, re
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc
import xbmcvfs
import requests
import base64
import string
import cookielib
import jsunpack
import cloudflare3x
from strings import *
from serviceLib import *
from CommonFunctions import parseDOM
from CommonFunctions import replaceHTMLCodes

serviceName         = 'HejoTV'
hejotvUrl           = 'https://hejo.tv'
homeUrl             = 'https://hejo.tv/home'

COOKIEFILE = os.path.join(xbmc.translatePath(ADDON.getAddonInfo('profile')), 'hejotv.cookie')
sess = requests.Session()
sess.cookies = cookielib.LWPCookieJar(COOKIEFILE)

kukz = ''
kukz2 = ''
packer = re.compile('(eval\(function\(p,a,c,k,e,(?:r|d).*)')

jakosc = ADDON.getSetting('hejotv_video_quality')

UA = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36'

headersok = {
    'User-Agent': UA,
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
    'Referer': 'https://hejo.tv/home',
    'Connection': 'keep-alive',
    'Upgrade-Insecure-Requests': '1',
    'Cache-Control': 'max-age=0',}

class HejoTVUpdater(baseServiceUpdater):
    def __init__(self):
        self.serviceName        = serviceName
        self.localMapFile       = 'hejotvmap.xml'
        baseServiceUpdater.__init__(self)
        self.serviceEnabled     = ADDON.getSetting('hejotv_enabled')
        self.login              = ADDON.getSetting('hejotv_username').strip()
        self.password           = ADDON.getSetting('hejotv_password').strip()
        self.servicePriority    = int(ADDON.getSetting('priority_hejotv'))
        self.url                = hejotvUrl
        self.addDuplicatesToList = True

    def cf_setCookies(self):
        sess.headers.update({
            'User-Agent': UA,
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
            'DNT': '1',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',})
        url = 'https://hejo.tv/'
        check = sess.get(url)
        cf = cloudflare3x.Cloudflare(url,check)
        token1=''
        if cf.is_cloudflare:
            authUrl = cf.get_url()
            makeAuth = sess.get(authUrl)
            result = sess.get(url).content
        dataPath=os.path.dirname(COOKIEFILE)
        if not os.path.exists(dataPath):
            os.makedirs(dataPath)
        if sess.cookies:
            sess.cookies.save(COOKIEFILE, ignore_discard = True)
        return 

        
    def cookieString(self, COOKIEFILE):
        sc=''
        if os.path.isfile(COOKIEFILE):
            sess.cookies.load(COOKIEFILE)
            sc=''.join(['%s=%s;'%(c.name, c.value) for c in sess.cookies])
        return sc  

    def getUrl(self, url, redir=True):
        sess.headers.update({'User-Agent': UA})
        if os.path.isfile(COOKIEFILE):
            sess.cookies.load(COOKIEFILE, ignore_discard = True)
        if redir:
            html = sess.get(url, cookies=sess.cookies, verify=False, allow_redirects=redir).content
        else:
            html = sess.get(url, cookies=sess.cookies, verify=False, allow_redirects=redir)#.content
        if 'function setCookie' in html:
            try:
                self.dodajKuki(html)
                self.getUrl(url)
            except:
                pass

        return html

    def dodajKuki(self, html):
        packer2 = re.compile('(eval\(function\(p,a,c,k,e,d\).+?{}\)\))')

        unpacked = ''
        packeds = packer2.findall(html)#[0]
        for packed in packeds:
            unpacked += jsunpack.unpack(packed)
        unpacked = unpacked.replace("\\'", '"')

        kukz = re.findall("""setCookie\(['"](.+?)['"],['"](.+?)['"]""",unpacked)[0]
        nowy_cookie = requests.cookies.create_cookie(kukz[0],kukz[1])
        sess.cookies.set_cookie(nowy_cookie)
        sess.cookies.save(COOKIEFILE, ignore_discard = True)
        return

    def zalogujponownie(exlink):
        sess.cookies.clear()
        username = self.login
        password = self.password
        
        if username and password == 'true':
            headers = {
                    'Host': 'hejo.tv',
                'User-Agent': UA,
                'Accept': 'text/html',
                'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
                'DNT': '1',
                'Upgrade-Insecure-Requests': '1',
            }
            
            response = sess.get('http://hejo.tv/', headers=headers,verify=False).content

            packer2 = re.compile('(eval\(function\(p,a,c,k,e,d\).+?{}\)\))')

            unpacked = ''
            packeds = packer2.findall(response)#[0]
            for packed in packeds:
                unpacked += jsunpack.unpack(packed)
            unpacked = unpacked.replace("\\'", '"')

            kukz = re.findall("""setCookie\(['"](.+?)['"],['"](.+?)['"]""",unpacked)[0]
            nowy_cookie = requests.cookies.create_cookie(kukz[0],kukz[1])

            sess.cookies.set_cookie(nowy_cookie)
            html = sess.get('http://hejo.tv/',verify=False).content
            token = parseDOM(html, 'meta', attrs={'name':'csrf-token'},ret='content')[0]  
            data = {'_token': token,'username': username,'password': password}
            response = sess.post('https://hejo.tv/login', data=data,verify=False).content
            packer2 = re.compile('(eval\(function\(p,a,c,k,e,d\).+?{}\)\))')
            unpacked = ''
            packeds = packer2.findall(response)#[0]
            for packed in packeds:
                unpacked += jsunpack.unpack(packed)
            unpacked = unpacked.replace("\\'", '"')
            kukz = re.findall("""setCookie\(['"](.+?)['"],['"](.+?)['"]""",unpacked)[0]
            nowy_cookie = requests.cookies.create_cookie(kukz[0],kukz[1])
            sess.cookies.set_cookie(nowy_cookie)
            html = sess.get('https://hejo.tv/login',verify=False).content

            if html.find('logowany jako')>0:
                sess.cookies.save(COOKIEFILE, ignore_discard = True)
        return

    def loginService(self):
        try:
            self.cf_setCookies()

            username = self.login
            password = self.password
            
            if username and password:
                mainurl = 'https://hejo.tv/'
                headers = {
                    'Host': 'hejo.tv',
                    'User-Agent': UA,
                    'Accept': 'text/html',
                    'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
                    'DNT': '1',
                    'Upgrade-Insecure-Requests': '1',
                }
                response = sess.get('http://hejo.tv/', headers=headers,verify=False).content
                packer2 = re.compile('(eval\(function\(p,a,c,k,e,d\).+?{}\)\))')
                unpacked = ''
                packeds = packer2.findall(response)#[0]
                for packed in packeds:
                    unpacked += jsunpack.unpack(packed)
                unpacked = unpacked.replace("\\'", '"')
                kukz = re.findall("""setCookie\(['"](.+?)['"],['"](.+?)['"]""",unpacked)[0]
                nowy_cookie = requests.cookies.create_cookie(kukz[0],kukz[1])
                sess.cookies.set_cookie(nowy_cookie)
                html = sess.get('http://hejo.tv/',verify=False).content
                token = parseDOM(html, 'meta', attrs={'name':'csrf-token'},ret='content')[0]  
                data = {'_token': token,'username': username,'password': password}
                response = sess.post('https://hejo.tv/login', data=data,verify=False).content
                packer2 = re.compile('(eval\(function\(p,a,c,k,e,d\).+?{}\)\))')
                unpacked = ''
                packeds = packer2.findall(response)#[0]
                for packed in packeds:
                    unpacked += jsunpack.unpack(packed)
                unpacked = unpacked.replace("\\'", '"')
                kukz = re.findall("""setCookie\(['"](.+?)['"],['"](.+?)['"]""",unpacked)[0]
                nowy_cookie = requests.cookies.create_cookie(kukz[0],kukz[1])
                sess.cookies.set_cookie(nowy_cookie)
                html = sess.get('https://hejo.tv/login',verify=False).content

                if html.find('logowany jako')>0:
                    sess.cookies.save(COOKIEFILE, ignore_discard = True)
                    if 'Wykup konto premium' in html:
                        self.log('Error when trying to login in internetowa.ws!, result: %s' % str(response))
                        self.noPremiumMessage()
                        return False
                    else:
                        info = (re.findall('>(Premium do.+?)</a>', html)[0]).lower()
                    log1 = re.findall("""class="fa fa-user" aria-hidden="true"></i>([^<]+)<""", html)[0]
                    return True
                else:
                    self.log('Error when trying to login in hejo.tv!, result: %s' % str(response))
                    self.loginErrorMessage() 
                    return False
        except:
            self.log('Exception while trying to log in: %s' % getExceptionString())
            self.loginErrorMessage()  
        return False

    def getChannelList(self, silent):
        result = list()

        if not self.loginService():
            return result

        self.log('\n\n')
        self.log('[UPD] Pobieram liste dostepnych kanalow %s z %s' % (self.serviceName, self.url))
        self.log('[UPD] -------------------------------------------------------------------------------------')
        self.log('[UPD] %-10s %-35s %-15s %-20s %-35s' % ( '-CID-', '-NAME-', '-GEOBLOCK-', '-ACCESS STATUS-', '-IMG-'))

        try:
            url = 'https://hejo.tv/'
            kuk = self.cookieString(COOKIEFILE)
            html = ''
    
            html += self.getUrl(url)
            for x in range(1, 6):
                urlk = 'https://hejo.tv/home?page=%s' % x
                html += self.getUrl(urlk)  
            links = parseDOM(html, 'div', attrs={'class': "col-lg-3 col-md-4 col-sm-6 col-12 p-2"}) 
            for link in links:
                cid = parseDOM(link, 'a', ret='href')[0]
                img = parseDOM(link, 'img', ret='src')[0]      
                name = parseDOM(link, 'img', ret='alt')[0]

                name = re.sub(r'(?i)(\s*(on|off)line)', '', name)

                program = TvCid(cid, name, name, img=img)

                result.append(program)

            if len(result) <= 0:
                self.log('Error while parsing service %s, returned data is: %s' % (self.serviceName, str(html)))
                self.noPremiumMessage()

        except:
            self.log('getChannelList exception: %s' % getExceptionString())
        return result

    def getChannelStream(self, chann):
        data = None
        url = chann.cid
        
        sess.headers.update({
            'User-Agent': UA,
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
            'Referer': 'https://hejo.tv/',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
        })
        
        try:
        
            html = self.getUrl(url)

            unpack = ''   
            
            htmlsy = re.findall('script.defer(.+?)$',html,re.DOTALL)[0]
            pack3 = re.compile('(eval\(function\(p,a,c,k,e,d\).+?\)\)\))')
            results = pack3.findall(htmlsy)#[0]
                
            for result in results:
                unpack += jsunpack.unpack(result)
            packer2 = re.compile('(eval\(function\(p,a,c,k,e,d\).+?{}\)\))') 
            results = packer2.findall(htmlsy)#[0]
            for result in results:

                unpack += jsunpack.unpack(result)
            
            unpack = unpack.replace("\\\'",'"')
            if 'setCookie' in unpack:
                self.zalogujponownie()
                self.getChannelStream(chann)
            
            api = re.findall('.get\("([^"]+)",function\(c\)',unpack)[0]
            nxturl = parseDOM(html, 'iframe', attrs={'name': "livetv","src":".+?"},ret='src')[0] 
            api = 'https://hejo.tv'+ api if api.startswith('/') else api



            chTbl = []
            
            headers2 = {
            'User-Agent': UA,
            'Accept': '*/*',
            'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
            'X-Requested-With': 'XMLHttpRequest',
            'Connection': 'keep-alive',
            'Referer': url,
            'TE': 'Trailers',
            }

            chTbl = sess.get(api, cookies=sess.cookies, headers=headers2, verify=False).json()

            headers = {
            'User-Agent': UA,
            'Accept': '*/*',
            'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
            'Referer': url,
            'X-Requested-With': 'XMLHttpRequest',
            'Connection': 'keep-alive',
            'TE': 'Trailers',}
            html = sess.get(nxturl, cookies=sess.cookies, headers=headers, verify=False)#.content

            ref = html.url
            html = html.content


            stream_url = re.findall("hls.loadSource\('(.+?)'\)",html)[0]
            
            pol = sess.get(stream_url, cookies=sess.cookies, headers=headers, verify=False).content
            jakoscstream_url = re.findall('RESOLUTION=(.+?)\\r\\n(htt.+?)\\r',pol,re.DOTALL)
            if jakoscstream_url:
                if jakosc == 'Auto':
                    stream_url = jakoscstream_url[0][1]
                else:
                    try:
                        for jak,href in jakoscstream_url:
                            if jakosc == jak:
                                stream_url = href
                            else:
                                continue

                    except:
                        stream_url = jakoscstream_url[0][1]

                #data = stream_url+'|Referer='+ref

                kuk = self.cookieString(COOKIEFILE)
                data = stream_url+'|User-Agent='+urllib.quote(UA)+'&Referer='+ref+'&Cookie='+urllib.quote(kuk)

            else:
                data = ''
        
            if data is not None and data != "":
                chann.strm = data
                self.log('getChannelStream found matching channel: cid: %s, name: %s, rtmp: %s' % (chann.cid, chann.name, chann.strm))
                return chann
            else:
                self.log('getChannelStream error getting channel stream2, result: %s' % str(data))
                return None
        except Exception, e:
            self.log('getChannelStream exception while looping: %s\n Data: %s' % (getExceptionString(), str(data)))
        return None