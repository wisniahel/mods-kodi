#!/usr/bin/env python
# -*- coding: utf-8 -*-

#   GNU General Public License

#   m-TVGuide KODI Addon
#   Copyright (C) 2020 Mariusz Brychcy

#   Some implementations are modified and taken from "plugin.video.cpgo" - thank you very much mbebe!

#   This program is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.

#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.

#   You should have received a copy of the GNU General Public License
#   along with this program. If not, see https://www.gnu.org/licenses.

#   MIT License

#   Permission is hereby granted, free of charge, to any person obtaining a copy
#   of this software and associated documentation files (the "Software"), to deal
#   in the Software without restriction, including without limitation the rights
#   to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
#   copies of the Software, and to permit persons to whom the Software is
#   furnished to do so, subject to the following conditions:

#   The above copyright notice and this permission notice shall be included in all
#   copies or substantial portions of the Software.

#   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
#   IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
#   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
#   AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
#   LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
#   OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
#   SOFTWARE.

from __future__ import unicode_literals

import sys

if sys.version_info[0] > 2:
    import urllib.request, urllib.parse, urllib.error
    from urllib.parse import parse_qsl
else:
    import urllib
    import urlparse
    from urlparse import parse_qsl

import re, os
import requests
import xbmc, xbmcaddon, xbmcgui, xbmcplugin, xbmcvfs
import string
from CommonFunctions import parseDOM
from CommonFunctions import replaceHTMLCodes

from strings import *
from serviceLib import *

import random
import time

serviceName         = 'Cyfrowy Polsat GO'

UA = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.9 Safari/537.36'

auth_url='https://b2c.redefine.pl/rpc/auth/'
navigate_url='https://b2c.redefine.pl/rpc/navigation/'

clid = ADDON.getSetting('clientId')
devid = ADDON.getSetting('devid')

stoken = ADDON.getSetting('sesstoken')
sexpir = ADDON.getSetting('sessexpir')
skey = ADDON.getSetting('sesskey')

class PolsatGoUpdater(baseServiceUpdater):
    def __init__(self):
        self.serviceName        = serviceName
        self.localMapFile       = 'polsatgomap.xml'
        baseServiceUpdater.__init__(self)
        self.serviceEnabled     = ADDON.getSetting('cpgo_enabled')
        self.login              = ADDON.getSetting('cpgo_username').strip()
        self.password           = ADDON.getSetting('cpgo_password').strip()
        self.servicePriority    = int(ADDON.getSetting('priority_cpgo'))
        self.addDuplicatesToList = True

    def loginService(self):
        try:
            headers = {
            'Host': 'b2c.redefine.pl',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.9 Safari/537.36',
            'Accept': 'application/json, text/plain, */*',
            'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
            'Content-Type': 'application/json; utf-8',
            'Origin': 'https://go.cyfrowypolsat.pl',
            'DNT': '1',
            'Referer': 'https://go.cyfrowypolsat.pl/',
            }
            osinfo = "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.9 Safari/537.36"
            uaipla = "www_iplatv/12345 (Mozilla/5.0 Windows NT 10.0; WOW64 AppleWebKit/537.36 KHTML, like Gecko Chrome/62.0.3202.9 Safari/537.36)"
            
            
            clid = ADDON.getSetting('clientId')
            devid = ADDON.getSetting('devid')
            
            stoken = ADDON.getSetting('sesstoken')
            sexpir = ADDON.getSetting('sessexpir')
            skey = ADDON.getSetting('sesskey')
            
            def gen_hex_code(myrange=6):
                return ''.join([random.choice('0123456789ABCDEF') for x in range(myrange)])
            
            def ipla_system_id():
                myrand = gen_hex_code(10) + '-' + gen_hex_code(4) + '-' + gen_hex_code(4) + '-' + gen_hex_code(4) + '-' + gen_hex_code(12)
            
                return myrand

            if not clid and not devid:
                clientid = ipla_system_id()
                deviceid = ipla_system_id()
                
                ADDON.setSetting('clientId', clientid)
                ADDON.setSetting('devid', deviceid)
                self.loginService()
                
            else:

                usernameCP = self.login
                passwordCP = self.password
                if usernameCP and passwordCP:
                    data = {"jsonrpc":"2.0","method":"login","id":1,"params":{"authData":{"loginICOK":usernameCP,"passwordICOK":passwordCP,"deviceIdICOK":{"value":devid,"type":"other"}},"ua":"cpgo_www/2015"}}
                    response = requests.post(auth_url, headers = headers, json = data, verify = False, timeout = 15).json()
                    try:
                        error = response['error']
                        dictLimit = error['data']
                        xbmcgui.Dialog().ok(strings(30353), str(error['message']) + '. Maximum limit: '+ str(dictLimit.get('limit')))
                        if error:
                            self.loginErrorMessage()
                        return False

                    except:
                        sesja = response['result']['session']

                        sesstoken = sesja['id']
                        sessexpir = str(sesja['keyExpirationTime'])
                        sesskey = sesja['key']
                        
                        ADDON.setSetting('sesstoken', sesstoken)
                        ADDON.setSetting('sessexpir', str(sessexpir))
                        ADDON.setSetting('sesskey', sesskey)
                        accesgroup = response['result']['accessGroups']

                        ADDON.setSetting('accgroups', str(accesgroup))
                        return True

                else:
                    self.loginErrorMessage()
                    return False

        except:
            self.log('Exception while trying to log in: %s' % getExceptionString())
            self.loginErrorMessage()  
        return False

    def getChannelList(self, silent):
        result = list()

        if not self.loginService():
            return result

        self.log('\n\n')
        self.log('[UPD] Pobieram liste dostepnych kanalow %s z %s' % (self.serviceName, self.url))
        self.log('[UPD] -------------------------------------------------------------------------------------')
        self.log('[UPD] %-10s %-35s %-15s %-20s %-35s' % ( '-CID-', '-NAME-', '-GEOBLOCK-', '-ACCESS STATUS-', '-IMG-'))

        try:     
            headers = {
            'Host': 'b2c.redefine.pl',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.9 Safari/537.36',
            'Accept': 'application/json, text/plain, */*',
            'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
            'Content-Type': 'application/json; utf-8',
            'Origin': 'https://go.cyfrowypolsat.pl',
            'DNT': '1',
            'Referer': 'https://go.cyfrowypolsat.pl/',
            }


            stoken = ADDON.getSetting('sesstoken')
            sexpir = ADDON.getSetting('sessexpir')


            items = []
            myperms = []
            ff = ADDON.getSetting('accgroups')
            lista = eval(ff)
            
            for l in lista:
                if 'sc:' in l:
                    myperms.append(l)

            dane = stoken+'|'+sexpir+'|navigation|getTvChannels'
            authdata = getHmac(dane)
            data = {"jsonrpc":"2.0","method":"getTvChannels","id":1,"params":{"filters":[],"ua":"cpgo_www/2015","authData":{"sessionToken":authdata}}}
            response = requests.post(navigate_url, headers=headers, json=data,verify=False,timeout=15).json()
            aa = response['result']['results']
            for i in aa:
                item = {}
                channelperms = i['grantExpression'].split('*')
                channelperms = [w.replace('+plat:all', '') for w in channelperms]   
                for j in myperms:
                    if j in channelperms:
                        img = i['thumbnails'][-1]['src']
                        cid = i['id']
                        name = i['title'].upper()

                        program = TvCid(cid, name, name, img=img)
                        result.append(program)
            
            if len(result) <= 0:
                self.log('Error while parsing service %s, returned data is: %s' % (self.serviceName, str(response)))
                self.noPremiumMessage()
        except:
            self.log('getChannelList exception: %s' % getExceptionString())
        return result 

    def getChannelStream(self, chann):
        data = None
        cpid = int(0)
        id = chann.cid

        try:
            stoken = ADDON.getSetting('sesstoken')
            sexpir = ADDON.getSetting('sessexpir')

            dane = stoken+'|'+sexpir+'|auth|getSession'
            authdata = getHmac(dane)
            
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0',
                'Accept': 'application/json, text/plain, */*',
                'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
                'Content-Type': 'application/json; utf-8',
                'Origin': 'https://go.cyfrowypolsat.pl',
                'Connection': 'keep-alive',
            }
            
            cdata = {"jsonrpc":"2.0","method":"getSession","id":1,"params":{"ua":"cpgo_www/2015","authData":{"sessionToken":authdata}}}
            
            response = requests.post(auth_url, headers=headers, json=cdata,verify=False,timeout=15).json()
            sesja = response['result']['session']
            
            sesstoken = sesja['id']
            sessexpir = str(sesja['keyExpirationTime'])
            sesskey = sesja['key']
            
            ADDON.setSetting('sesstoken', sesstoken)
            ADDON.setSetting('sessexpir', str(sessexpir))
            ADDON.setSetting('sesskey', sesskey)
            
            stoken = ADDON.getSetting('sesstoken')
            sexpir = ADDON.getSetting('sessexpir')
            
            
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.9 Safari/537.36',
                'Accept': '*/*',
                'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
                'Content-Type': 'text/plain;charset=UTF-8',
                'Origin': 'https://go.cyfrowypolsat.pl',
                'Connection': 'keep-alive',
                'Referer': 'https://go.cyfrowypolsat.pl/tv/channel/'+id,
            }
            dane = stoken+'|'+sexpir+'|navigation|prePlayData'
            authdata = getHmac(dane)
            cdata = {"jsonrpc":"2.0","id":1,"method":"prePlayData","params":{"ua":"cpgo_www_html5/2 (Windows 10; widevine=true)","cpid":cpid,"mediaId":id,"authData":{"sessionToken":authdata}}}
            
            response = requests.post(navigate_url, headers=headers, json=cdata,verify=False,timeout=15).json()
            playback = response['result']['mediaItem']['playback']
            mediaid = playback['mediaId']['id']
            mediaSources = playback['mediaSources'][0]
            keyid = mediaSources['keyId']
            sourceid = mediaSources['id']

            stream_url = mediaSources['url']
            dane = stoken+'|'+sexpir+'|drm|getWidevineLicense'
            authdata = getHmac(dane)
            devcid = devid.replace('-','')
            if sys.version_info[0] > 2:
                cdata = urllib.parse.quote('{"jsonrpc":"2.0","id":1,"method":"getWidevineLicense","params":{"cpid":%d,"mediaId":"'%cpid+mediaid+'","sourceId":"'+sourceid+'","keyId":"'+keyid+'","object":"b{SSM}","deviceId":{"type":"other","value":"'+devcid+'"},"ua":"cpgo_www_html5/2","authData":{"sessionToken":"'+authdata+'"}}}')
            else:
                cdata = urllib.quote('{"jsonrpc":"2.0","id":1,"method":"getWidevineLicense","params":{"cpid":%d,"mediaId":"'%cpid+mediaid+'","sourceId":"'+sourceid+'","keyId":"'+keyid+'","object":"b{SSM}","deviceId":{"type":"other","value":"'+devcid+'"},"ua":"cpgo_www_html5/2","authData":{"sessionToken":"'+authdata+'"}}}')
            self.profilePath = xbmc.translatePath(ADDON.getAddonInfo('profile'))
            file_name = os.path.join(self.profilePath, 'drm_cpgo.ini')
            f = xbmcvfs.File(file_name, "wb")
            s = "%s" % str(cdata)
            f.write(str(s))
            f.close()

            data = stream_url
        
            if data is not None and data != "":
                chann.strm = data
                self.log('getChannelStream found matching channel: cid: %s, name: %s, rtmp: %s' % (chann.cid, chann.name, chann.strm))
                return chann
            else:
                self.log('getChannelStream error getting channel stream2, result: %s' % str(data))
                return None
        except Exception as e:
            self.log('getChannelStream exception while looping: %s\n Data: %s' % (getExceptionString(), str(data)))
        return None

def getHmac(dane):
    skey = ADDON.getSetting('sesskey')
    import hmac
    import hashlib 
    import binascii
    import base64
    from hashlib import sha256
    ssdalej=dane
    import base64
    
    def base64_decode(s):
        s = str(s).strip()
        try:
            return base64.b64decode(s)
        except TypeError:
            padding = len(s) % 4
            if padding == 1:
                return ''
            elif padding == 2:
                s += b'=='
            elif padding == 3:
                s += b'='

            return base64.b64decode(s)

    secretAccessKey = base64_decode(skey.replace('-','+').replace('_','/'))

    auth = hmac.new(secretAccessKey, ssdalej.encode("ascii"), sha256)
    vv = base64.b64encode(auth.digest())   
    
    return ssdalej+'|'+vv.decode().replace('+','-').replace('/','_')