#
#      Copyright (C) 2013 Szakalit
#
#
#  This Program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2, or (at your option)
#  any later version.
#
#  This Program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this Program; see the file LICENSE.txt.  If not, write to
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
#  http://www.gnu.org/copyleft/gpl.html
#
import os, shutil
import xbmc, xbmcgui, xbmcvfs
import source as src
from strings import *

class clearCMore:

    def __init__(self):
    	self.reset_login()
        deb('ClearCMore Completed')

    def set_setting(self, key, value):
        return xbmcaddon.Addon('script.mtvguide').setSetting(key, value)

    def reset_login(self):
        self.set_setting('cmore_operator', '')
        self.set_setting('cmore_operator_title', '')
        self.set_setting('cmore_username', '')
        self.set_setting('cmore_password', '')
        self.set_setting('login_token', '')
        xbmcgui.Dialog().ok(strings(30371).encode('utf-8'), strings(30372).encode('utf-8'))

clearcmore = clearCMore()