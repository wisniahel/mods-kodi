#!/usr/bin/env python
# -*- coding: utf-8 -*-

#   GNU General Public License

#   m-TVGuide KODI Addon
#   Copyright (C) 2019 Mariusz Brychcy

#   Some implementations are modified and taken from "plugin.video.internetws" - thank you very much mbebe!

#   This program is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.

#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.

#   You should have received a copy of the GNU General Public License
#   along with this program. If not, see https://www.gnu.org/licenses.

#   MIT License

#   Permission is hereby granted, free of charge, to any person obtaining a copy
#   of this software and associated documentation files (the "Software"), to deal
#   in the Software without restriction, including without limitation the rights
#   to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
#   copies of the Software, and to permit persons to whom the Software is
#   furnished to do so, subject to the following conditions:

#   The above copyright notice and this permission notice shall be included in all
#   copies or substantial portions of the Software.

#   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
#   IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
#   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
#   AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
#   LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
#   OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
#   SOFTWARE.

from __future__ import unicode_literals

import sys

if sys.version_info[0] > 2:
    import http.cookiejar
else:
    import cookielib

import os, copy, re
import xbmc, xbmcaddon, xbmcgui, xbmcplugin, xbmcvfs
import requests
import string
import internetwskb as kb
from strings import *
from serviceLib import *
from CommonFunctions import parseDOM 

serviceName         = 'Internetowa.ws'
internetwsUrl       = 'https://internetowa.tv/'
COOKIEFILE = os.path.join(xbmc.translatePath(ADDON.getAddonInfo('profile')) , 'intws.cookie')
sess = requests.Session()
if sys.version_info[0] > 2:
    sess.cookies = http.cookiejar.LWPCookieJar(COOKIEFILE)
else:
    sess.cookies = cookielib.LWPCookieJar(COOKIEFILE)

class InternetwsUpdater(baseServiceUpdater):
    def __init__(self):
        self.serviceName        = serviceName
        self.localMapFile       = 'internetwsmap.xml'
        baseServiceUpdater.__init__(self)
        self.serviceEnabled     = ADDON.getSetting('internetws_enabled')
        self.login              = ADDON.getSetting('internetws_username').strip()
        self.password           = ADDON.getSetting('internetws_password').strip()
        self.servicePriority    = int(ADDON.getSetting('priority_internetws'))
        self.url                = internetwsUrl
        self.addDuplicatesToList = True

    def loginService(self):
        try:       
            username = self.login
            password = self.password
            lastl = ADDON.getSetting('lastl')
            lastp = ADDON.getSetting('lastp') 
            
            if username and password:
                sess.headers = {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:61.0) Gecko/20100101 Firefox/66.0',
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                    'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
                    'Referer': 'https://internetowa.tv/logowanie/',
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'Connection': 'keep-alive',
                    'Upgrade-Insecure-Requests': '1',}  
                if lastl == username and lastp == password:
                    if os.path.isfile(COOKIEFILE):
                        sess.cookies.load() 
                else:
                    sess.cookies.clear()    
                html = sess.get('https://internetowa.tv/logowanie/', headers=sess.headers,cookies=sess.cookies)
                if sys.version_info[0] > 2:
                    captcha = re.search('https://internetowa.tv/captcha/', html.content.decode())
                else:
                    captcha = re.search('https://internetowa.tv/captcha/', html.content)

                if captcha:
                    headers = {
                        'Host': 'internetowa.tv',
                        'user-agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:61.0) Gecko/20100101 Firefox/66.0',
                        'accept': 'image/webp,*/*',
                        'accept-language': 'pl,en-US;q=0.7,en;q=0.3',
                        'referer': 'https://internetowa.tv/logowanie/',
                        'dnt': '1',
                        'te': 'trailers',
                    }
                    
                    response = sess.get('https://internetowa.tv/captcha/', cookies=html.cookies, headers=headers, verify=False)
                    
                    search_term = kb.Keyboard(response.content)

                    data = {'email': username,'password': password,'captcha':search_term}
                else:
                    data = {'email': username,'password': password}
                response = sess.post('https://internetowa.tv/logowanie/#', headers=sess.headers, data=data, allow_redirects=False) 

                if response.cookies.get('login') is not None:
                    sess.cookies.save() 
                    ADDON.setSetting("lastl", username)
                    ADDON.setSetting("lastp", password)
                #if os.path.isfile(COOKIEFILE):
                    sess.cookies.load()     
                #sess.cookies.load()    
                if sys.version_info[0] > 2:
                    html = sess.get('https://internetowa.tv/konto/', cookies=sess.cookies).content.decode()
                else:
                    html = sess.get('https://internetowa.tv/konto/', cookies=sess.cookies).content

                premium = re.findall('Konto premium, wa.+?ne do (.+?). Masz', html)
                if premium:
                    xbmcgui.Dialog().notification('Internetowa.ws', 'Premium: '+ premium[0])
                free = re.findall('Brak konta premium', html)
                if premium:
                    info = premium[0]                          
                    return True
                elif free:
                    self.log('Error when trying to login in internetowa.ws!, result: %s' % str(response))
                    self.noPremiumMessage()
                    sess.cookies.clear()
                    sess.cookies.save() 
                    return False
                else:
                    self.log('Error when trying to login in internetowa.ws!, result: %s' % str(response))
                    self.loginErrorMessage()
                    sess.cookies.clear()
                    sess.cookies.save() 
                    return False              
            else:
                self.log('Error when trying to login in internetowa.ws!, result: %s' % str(response))
                self.loginErrorMessage()
                sess.cookies.clear()
                sess.cookies.save()  
                return False 

        except:
            self.log('Exception while trying to log in: %s' % getExceptionString())
            self.loginErrorMessage()
        return False

    def getChannelList(self, silent):
        result = list()

        if not self.loginService():
            return result

        self.log('\n\n')
        self.log('[UPD] Pobieram liste dostepnych kanalow %s z %s' % (self.serviceName, self.url))
        self.log('[UPD] -------------------------------------------------------------------------------------')
        self.log('[UPD] %-10s %-35s %-15s %-20s %-35s' % ( '-CID-', '-NAME-', '-GEOBLOCK-', '-ACCESS STATUS-', '-IMG-'))
        
        try:
            sess.cookies.load() 
            html = sess.get('https://internetowa.tv/', cookies=sess.cookies).text      
            parse_result = parseDOM(html,'div', attrs={'id': "allhome"})[0] 

            items = parseDOM(parse_result,'div', attrs={'class': "channelb"})#[0] 
            if sys.version_info[0] > 2:
                html = sess.get('https://internetowa.tv/program-tv/').content.decode()
            else:
                html = sess.get('https://internetowa.tv/program-tv/').content
            parse_result = parseDOM(html,'div', attrs={'id': "epgBig"})[0] 
            subset = parseDOM(result,'tr')        
            for item in items:
                if sys.version_info[0] > 2:
                    cid = parseDOM(item, 'a', ret='href')[0]
                    img = parseDOM(item, 'img', ret='src')[0]
                    name = parseDOM(item, 'a', ret='title')[0]
                else:
                    cid = parseDOM(item, b'a', ret=b'href')[0]
                    img = parseDOM(item, b'img', ret=b'src')[0]
                    name = parseDOM(item, b'a', ret=b'title')[0]

                program = TvCid(cid, name, name, img=img)
                result.append(program)


            if len(result) <= 0:
                self.log('Error while parsing service %s, returned data is: %s' % (self.serviceName, str(html)))
                self.noPremiumMessage()

        except:
            self.log('getChannelList exception: %s' % getExceptionString())
        return result

    def getChannelStream(self, chann):
        data = None

        head = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:61.0) Gecko/20100101 Firefox/66.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
        'Connection': 'keep-alive',
        'Referer': 'https://internetowa.tv/',
        'Upgrade-Insecure-Requests': '1',
        'TE': 'Trailers',
        }

        if 'm3u8' in chann.cid:
            stream_url = chann.cid
            data = stream_url
        else:
            try:
                if os.path.isfile(COOKIEFILE):
                    sess.cookies.load() 
                if sys.version_info[0] > 2:
                    html = sess.get(chann.cid,headers=head,verify=False).content.decode()
                else:
                    html = sess.get(chann.cid,headers=head,verify=False).content
                hlsToken = re.findall("""hlsToken\s*=\s*['"](.+?)['"]""",html)
                chromecastUrl = re.findall("""chromecastUrl\s*=\s*['"](.+?)['"]""",html)
                if chromecastUrl and hlsToken:
                    if sys.version_info[0] > 2:
                        stream_url = chromecastUrl[0]+urllib.parse.quote(hlsToken[0])+'|Referer='+urllib.parse.quote(chann.cid)
                    else:
                        stream_url = chromecastUrl[0]+urllib.quote(hlsToken[0])+'|Referer='+urllib.quote(chann.cid)
                else:
                    trick=re.findall('vid1.src([^<]+)<',html)
                    if trick:
                        stream_url=re.findall("""src: ['"]([^'"]+)['"]""",trick[0].replace("\'",'"'))[0]
                        if sys.version_info[0] > 2:
                            band = sess.get(stream_url, headers=head, verify=False).content.decode()
                        else:
                            band = sess.get(stream_url, headers=head, verify=False).content
                        stream_url= re.findall("(http.+?)\\r", band.decode('utf-8'), re.MULTILINE)[0]
                        stream_url+='|Referer='+chann.cid   
                    else:
                        iframe = parseDOM(html, 'iframe', ret='src')[0]
                        sess.headers.update({'Referer': chann.cid})
                        html=(sess.get(iframe,headers=head,verify=False).content).replace("\'",'"')
                        
                        if 'js/hls.js' in html:
                            stream_u=re.findall("""hls.loadSource\(['"](.+?)['"]\)""",html)[0]
                        else:
                            stream_u=re.findall('src="(.+?m3u8.+?)"',html)[0]
                        stream_url = stream_u +'|Referer='+iframe

                data = stream_url

                if data is not None and data != "":
                    chann.strm = data
                    self.log('getChannelStream found matching channel: cid: %s, name: %s, rtmp: %s' % (chann.cid, chann.name, chann.strm))
                    return chann
                else:
                    self.log('getChannelStream error getting channel stream2, result: %s' % str(data))
                    return None
            except Exception as e:
                self.log('getChannelStream exception while looping: %s\n Data: %s' % (getExceptionString(), str(data)))
            return None
        

